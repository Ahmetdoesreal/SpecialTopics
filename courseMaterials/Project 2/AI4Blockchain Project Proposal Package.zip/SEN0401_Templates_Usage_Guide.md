# SEN0401 PROJECT TEMPLATES - USAGE GUIDE

## 📋 Overview

This guide explains how to use the three project templates created for **SEN0401 Special Topics in Software Engineering: Blockchain** course with the **AI4Blockchain / Agentic Development** theme.

**Course Information:**
- **Instructor:** Yusuf Altunel (y.altunel@iku.edu.tr)
- **Course:** SEN0401 - Special Topics in Software Engineering (Blockchain)
- **Theme:** AI Agents for Blockchain (expanded to AI4Blockchain concepts)
- **Institution:** Istanbul Kültür University, Computer Engineering Department

---

## 📁 Available Templates

You have been provided with **THREE comprehensive templates**:

### 1. **Empty Project Proposal Template** 
   - **File:** `SEN0401_Project_Proposal_Template_Empty.docx`
   - **Purpose:** Start your project by filling this out
   - **When to use:** Beginning of semester / Before starting project work
   - **Size:** 15+ pages with detailed sections

### 2. **Example Filled Proposal**
   - **File:** `SEN0401_Project_Proposal_Example_Filled.docx`
   - **Purpose:** See a realistic, complete example
   - **Project:** "AI-Powered DAO Governance Analyzer"
   - **When to use:** Reference while filling your own proposal

### 3. **Final Project Report Template**
   - **File:** `SEN0401_Final_Project_Report_Template.docx`
   - **Purpose:** Document completed project
   - **When to use:** End of semester / After project completion
   - **Size:** Comprehensive report structure

---

## 🎯 Project Grading Breakdown

Based on course outline:
- **10%** - Bonus (optional activities)
- **30%** - Midterm exam
- **30%** - Project (THIS)
- **40%** - Final exam
- **Total:** 110% possible

**Your project (30% of grade) evaluation will consider:**
- Proposal quality and completeness
- Implementation of AI4Blockchain concepts
- Technical execution (AI + Blockchain integration)
- Final report documentation
- Presentation and demonstration

---

## 📝 How to Use the Empty Proposal Template

### STEP 1: Download and Save
1. Download: `SEN0401_Project_Proposal_Template_Empty.docx`
2. Save as: `[YourProjectName]_Proposal_[YourName].docx`
3. Example: `DAO_Analyzer_Proposal_AhmetYilmaz.docx`

### STEP 2: Complete Header Information
Fill out the project information table at the top:
- **Project Title:** Choose a clear, descriptive name
- **Version:** Start with 1.0
- **Status:** Check "Draft" initially
- **Submitted By:** Your name(s)
- **Student ID(s):** Your student ID number(s)
- **Date:** Submission date

### STEP 3: Work Through Each Section

#### Section 1: Executive Summary (10-15 minutes)
Write 2-3 paragraphs covering:
- What problem are you solving?
- How will you combine AI + blockchain?
- What will you build?
- Who will use it?

**Tip:** Write this LAST after completing other sections, but it appears first.

#### Section 2: AI4Blockchain Classification (30-45 minutes)
This is CRITICAL for the AI4Blockchain theme:

**2.1 Primary Domain Focus**
Select your main AI4Blockchain domain:
- ☐ **AI4DAO** - DAO governance, voting, proposal analysis
- ☐ **AI4DeFi** - Yield optimization, risk assessment, price prediction
- ☐ **AI4DApps** - Smart contract optimization, dApp enhancement
- ☐ **AI4NFT** - NFT analytics, rarity scoring, price prediction
- ☐ **AI4Web3** - Identity, data indexing, cross-chain bridges

**2.2 AI Components Used**
Check ALL AI technologies you'll use:
- Machine Learning (supervised, unsupervised, reinforcement)
- Deep Learning (neural networks, CNNs, RNNs, transformers)
- NLP (text analysis, language models, sentiment analysis)
- Computer Vision (if applicable)
- AI Agents (autonomous agents, multi-agent systems)

**2.3 Blockchain Components**
Specify:
- **Platform:** Ethereum, Polygon, Bitcoin, etc.
- **Smart Contracts:** Solidity, Vyper, etc.
- **Tools:** Hardhat, Truffle, OpenZeppelin, The Graph, Chainlink

**2.4 Integration Architecture**
Explain how AI and blockchain work together:
- What runs off-chain (AI models)?
- What runs on-chain (smart contracts)?
- How do they communicate (oracles, APIs)?

**💡 Why This Matters:** This section proves you understand the AI4Blockchain taxonomy and can properly classify your project within the 443-class ontology.

#### Section 3: Problem Statement (20-30 minutes)
Clearly define:
- **3.1:** What problem exists? Why does it matter?
- **3.2:** Why do you need BOTH AI AND blockchain?
  - What can't AI alone solve?
  - What can't blockchain alone solve?
- **3.3:** Who are your target users?

#### Section 4: Proposed Solution (45-60 minutes)
Describe your solution in detail:
- **4.1:** High-level overview of your approach
- **4.2:** Core features (MUST implement)
- **4.3:** Optional features (nice to have)
- **4.4:** Functional requirements (specific, measurable)
- **4.5:** Non-functional requirements (performance, security, usability)

**Use the tables provided** - they help organize requirements clearly.

#### Section 5: Technical Architecture (45-60 minutes)
This is where you get technical:
- **5.1:** System architecture diagram (can draw and insert image)
- **5.2:** Technology stack for each layer:
  - Frontend (React, Vue, etc.)
  - Backend/AI (Python, PyTorch, LangChain, etc.)
  - Blockchain (Ethereum, Solidity, Hardhat, etc.)
  - Infrastructure (databases, oracles, indexers)
- **5.3:** Data flow between components

**💡 Tip:** Be specific about versions and libraries you'll use.

#### Section 6: Development Plan (30-45 minutes)
Plan your semester:
- **6.1:** Choose methodology (Agile recommended for flexibility)
- **6.2:** Timeline with phases:
  - Research & Requirements (2-3 weeks)
  - Design & Architecture (2 weeks)
  - Smart Contract Development (3-4 weeks)
  - AI Model Development (3-4 weeks)
  - Integration & Frontend (3-4 weeks)
  - Testing & QA (2 weeks)
  - Documentation & Deployment (1-2 weeks)
- **6.3:** Key milestones with dates

**💡 Tip:** Work backwards from final presentation date.

#### Section 7: Team & Resources (15-20 minutes)
- **7.1:** List all team members with roles
- **7.2:** Distribute responsibilities:
  - Who does smart contracts?
  - Who does AI/ML?
  - Who does frontend?
  - Who does testing?

**💡 Tip:** Be realistic about your team's skills and time.

#### Section 8: Risk Management (20-30 minutes)
Identify potential problems:
- **8.1:** Technical risks (vulnerabilities, accuracy issues, etc.)
- **8.2:** Project risks (scope creep, time management, etc.)

For each risk:
- Assess impact (Low/Medium/High)
- Assess probability (Low/Medium/High)
- Define mitigation strategy

#### Section 9: Testing & Quality Assurance (15-20 minutes)
Plan your testing:
- Smart contract testing (unit, integration, security)
- AI model validation (accuracy, performance)
- System testing (end-to-end, UAT)
- Quality metrics (code coverage, model accuracy, etc.)

#### Section 10: Expected Outcomes (15-20 minutes)
- **10.1:** List concrete deliverables
- **10.2:** Define success criteria (measurable!)
- **10.3:** Describe expected impact

#### Section 11: References (10-15 minutes)
List your sources:
- Academic papers
- Technical documentation
- Similar projects

**Format:** Follow standard academic citation format.

#### Section 12: Approval (2 minutes)
- Team members sign/date
- Submit for instructor approval

### STEP 4: Review and Polish (30-60 minutes)
Before submission:
- ✅ All sections completed?
- ✅ No placeholder text remaining?
- ✅ Consistent formatting?
- ✅ Grammar and spelling checked?
- ✅ Tables filled correctly?
- ✅ Realistic timeline?
- ✅ Clear AI + blockchain integration?

---

## 📖 How to Use the Example Proposal

**File:** `SEN0401_Project_Proposal_Example_Filled.docx`

This is a **reference example** showing a complete, realistic proposal for an "AI-Powered DAO Governance Analyzer" project.

### How to Use It:

#### 1. **Study the Structure**
- See how each section is filled out
- Understand the level of detail expected
- Note the writing style and tone

#### 2. **Learn from the AI4Blockchain Classification**
The example shows:
- ✅ Clear primary domain selection (AI4DAO)
- ✅ Specific AI components listed (NLP, ML models)
- ✅ Concrete blockchain technologies (Ethereum, The Graph)
- ✅ Integration architecture explained

#### 3. **Understand Problem Definition**
Notice how the example:
- Identifies a real DAO governance problem
- Explains why both AI and blockchain are needed
- Defines specific target users

#### 4. **See Technical Detail Level**
The example demonstrates:
- Appropriate technical depth
- Specific technology choices
- Realistic implementation plans

#### 5. **What NOT to Do**
❌ Don't copy the example directly
❌ Don't use the same project idea
✅ DO use it as a template for quality and completeness

### Differences Between Your Project and Example:

| Aspect | Example Project | Your Project |
|--------|----------------|--------------|
| Domain | AI4DAO | [Choose your domain] |
| Problem | DAO governance | [Your problem] |
| AI Components | NLP + ML | [Your AI tech] |
| Blockchain | Ethereum + Polygon | [Your blockchain] |
| Target Users | DAO token holders | [Your users] |

---

## 📊 How to Use the Final Report Template

**File:** `SEN0401_Final_Project_Report_Template.docx`

This is for **AFTER** you complete your project.

### When to Start:
- Start documenting as you go (don't wait until the end!)
- Take screenshots during development
- Keep notes on challenges and solutions
- Record test results and metrics

### Report Structure:

#### Executive Summary
- Brief overview of what you built
- Key outcomes and achievements
- Lessons learned (2-3 paragraphs)

#### 1. Introduction
- Background and motivation
- Project objectives (from proposal)

#### 2. System Design & Architecture
- Overall architecture (with updated diagrams)
- AI components (models, algorithms used)
- Blockchain components (deployed contracts)
- Integration layer (how they connect)

#### 3. Implementation
- Technology stack (final versions used)
- Key features implemented (with screenshots!)
- Smart contract implementation details
- AI/ML model development:
  - Data collection & preprocessing
  - Model architecture
  - Training process and results

#### 4. Testing & Validation
- Smart contract testing results
  - Unit test coverage
  - Integration tests
  - Security audit findings
- AI model validation
  - Accuracy, precision, recall
  - Performance metrics
- System integration testing

#### 5. Results & Evaluation
- Achievement of objectives (did you meet your goals?)
- Performance analysis (how well does it work?)
- Demo and screenshots (INCLUDE THESE!)

#### 6. Challenges & Solutions
- Technical challenges encountered
- How you solved them
- Project management lessons

#### 7. Conclusions & Future Work
- Summary of achievements
- Lessons learned (technical and team)
- Future improvements and enhancements

#### 8. References
- All sources cited in proper format

#### Appendices
- **Appendix A:** Source code repository (GitHub link)
- **Appendix B:** User manual or documentation
- **Appendix C:** Additional diagrams and screenshots

### Report Tips:

✅ **DO:**
- Include lots of screenshots showing your system working
- Show actual test results and metrics
- Be honest about challenges and how you overcame them
- Provide GitHub repository link
- Include demo video link
- Cite all sources properly

❌ **DON'T:**
- Just describe what you planned to do
- Inflate results or hide problems
- Skip testing documentation
- Forget to include source code links
- Wait until last minute to write

### Recommended Approach:

**Throughout Semester:**
1. Keep a development log/journal
2. Take screenshots at each milestone
3. Save test results and metrics
4. Document challenges as they happen

**Final Week:**
1. Compile all documentation
2. Write the report sections
3. Add all screenshots and diagrams
4. Polish and proofread
5. Submit on time!

---

## 🎨 AI4Blockchain Taxonomy Quick Reference

Your project should align with the AI4Blockchain ontology (443 classes across 10 domains). Here's a quick reference:

### **Layer 0: Meta-Architecture** (23 classes)
Foundation patterns, quality gates, extensibility mechanisms
- Use if: Building framework-level components

### **Cross-Layer Infrastructure** (14 classes)
Bridges between AI and blockchain
- DataFlowIntegration, OracleMechanism, StateManagement

### **AI Domain** (120 classes)

#### Machine Learning (30 classes)
- Supervised: Classification, Regression
- Unsupervised: Clustering, Dimensionality Reduction
- Reinforcement: Q-Learning, Policy Gradient

#### Deep Learning (35 classes)
- Neural Networks: DNN, CNN, RNN, LSTM
- Transformers, GANs, VAEs

#### NLP (25 classes)
- Text Analysis, Sentiment Analysis
- Language Models (GPT, BERT)
- Named Entity Recognition

#### Computer Vision (15 classes)
- Image Classification, Object Detection
- (If your project uses images/NFTs)

### **Blockchain Domain** (80 classes)
- Smart Contracts, Consensus Mechanisms
- DeFi protocols, NFT standards
- Layer 1/Layer 2 solutions

### **AI4Blockchain Specializations** (79 classes)

#### AI4DAO (19 classes)
- **ProposalAnalyzer** - Analyze DAO proposals
- **VotingPredictor** - Predict voting outcomes
- **GovernanceOptimizer** - Optimize governance processes
- **ReputationScorer** - Score member reputation

#### AI4DeFi (16 classes)
- **YieldOptimizer** - Optimize yield farming
- **RiskAssessor** - Assess protocol risks
- **PricePredictor** - Predict token prices
- **LiquidityManager** - Manage liquidity pools

#### AI4DApps (17 classes)
- **SmartContractOptimizer** - Optimize contract code
- **GasPredictor** - Predict gas costs
- **UserBehaviorAnalyzer** - Analyze user patterns
- **TestGenerator** - Generate test cases

#### AI4NFT (15 classes)
- **RarityScorer** - Score NFT rarity
- **PricePredictor** - Predict NFT prices
- **FraudDetector** - Detect fake/stolen NFTs
- **MarketAnalyzer** - Analyze NFT markets

#### AI4Web3 (12 classes)
- **IdentityManager** - Manage decentralized identity
- **DataIndexer** - Index blockchain data
- **CrossChainBridge** - Bridge assets across chains

**💡 How to Use This:**
1. Identify which AI4Blockchain class(es) your project implements
2. Reference them in your proposal (Section 2.1)
3. Use the terminology consistently throughout

---

## 💡 Tips for Success

### General Tips:

1. **Start Early**
   - Don't wait until deadline approaches
   - Complex projects take time to mature

2. **Be Realistic**
   - Choose a scope you can complete in one semester
   - Focus on core features, not everything

3. **Use the Example**
   - Study the example proposal carefully
   - Match its level of detail and clarity

4. **Get Feedback Early**
   - Share draft proposal with instructor
   - Iterate based on feedback

5. **Document Everything**
   - Keep notes as you develop
   - Take screenshots regularly
   - Save test results

### Technical Tips:

1. **AI + Blockchain Integration**
   - Clearly separate on-chain and off-chain components
   - Use oracles for data bridges
   - Consider gas costs for frequent AI updates

2. **Testing is Critical**
   - Smart contracts need thorough testing
   - AI models need validation data
   - Integration testing catches surprises

3. **Start Simple**
   - Get basic integration working first
   - Add complexity incrementally
   - MVP approach works best

### Team Tips:

1. **Communication**
   - Regular team meetings (weekly minimum)
   - Use project management tools (Trello, Jira)
   - Document decisions

2. **Skill Distribution**
   - Match tasks to team members' strengths
   - But everyone should learn about both AI and blockchain
   - Cross-train when possible

3. **Conflict Resolution**
   - Address issues early
   - Instructor can mediate if needed
   - Keep team dynamic professional

---

## ✅ Submission Checklist

### For Proposal Submission:

- [ ] All sections of template completed
- [ ] No placeholder text or "[...]" remaining
- [ ] AI4Blockchain classification clearly specified
- [ ] Technology stack fully defined
- [ ] Timeline includes specific dates
- [ ] Team member responsibilities assigned
- [ ] Risks identified with mitigation plans
- [ ] References formatted correctly
- [ ] Document proofread for grammar/spelling
- [ ] Saved as: `[ProjectName]_Proposal_[Names].docx`
- [ ] Submitted before deadline

### For Final Report Submission:

- [ ] All proposal objectives addressed
- [ ] Implementation section completed with details
- [ ] Screenshots of working system included
- [ ] Test results documented with metrics
- [ ] GitHub repository link included
- [ ] Demo video link included (if available)
- [ ] Challenges and solutions described
- [ ] Lessons learned section completed
- [ ] Future work identified
- [ ] All references cited properly
- [ ] Appendices include source code access
- [ ] Document proofread for grammar/spelling
- [ ] Saved as: `[ProjectName]_FinalReport_[Names].docx`
- [ ] Submitted before deadline

---

## 📞 Getting Help

If you need assistance:

### Course Resources:
- **Instructor:** Yusuf Altunel (y.altunel@iku.edu.tr)
- **Course Portal:** http://cats.iku.edu.tr/
- **Office Hours:** [Check course schedule]

### Technical Resources:
- **AI4Blockchain Ontology:** Refer to taxonomy files provided
- **Ethereum Docs:** https://ethereum.org/en/developers/docs/
- **PyTorch Tutorials:** https://pytorch.org/tutorials/
- **Solidity Docs:** https://docs.soliditylang.org/

### Example Projects:
- Look for open-source AI4Blockchain projects on GitHub
- Study DAO governance systems (Compound, Uniswap, Aave)
- Explore DeFi protocols with AI components

---

## 🎓 Evaluation Criteria

Your project will be evaluated on:

### Proposal (Initial Grade):
- **Clarity & Completeness** (30%): All sections filled appropriately
- **AI4Blockchain Alignment** (25%): Proper use of taxonomy concepts
- **Technical Feasibility** (25%): Realistic scope and technology choices
- **Innovation** (20%): Novel approach or interesting problem

### Final Project (Final Grade):
- **Implementation Quality** (30%): Code quality, architecture, functionality
- **AI-Blockchain Integration** (25%): Effective combination of both technologies
- **Testing & Documentation** (20%): Thorough testing, clear documentation
- **Presentation & Demo** (15%): Clear explanation, working demonstration
- **Report Quality** (10%): Comprehensive, well-written final report

**Bonus Points Available For:**
- Exceptional innovation or technical achievement
- Published open-source contribution
- Deployed working system (beyond testnet)
- Comprehensive user testing with results

---

## 🚀 Success Stories & Inspiration

Good AI4Blockchain project topics:

### AI4DAO Projects:
- AI-powered proposal analysis and recommendation systems
- Automated governance quality scoring
- Voter behavior prediction and engagement optimization
- Smart delegation systems with AI advisors

### AI4DeFi Projects:
- Yield farming strategy optimizers
- DeFi risk assessment dashboards
- Impermanent loss predictors
- Liquidation risk monitoring systems

### AI4DApps Projects:
- Smart contract vulnerability detection
- Gas optimization recommenders
- Automated test generation
- User behavior analytics for dApps

### AI4NFT Projects:
- NFT rarity scoring engines
- Price prediction models
- Fraud detection systems
- Collection analytics platforms

### Educational/Gamification Projects:
- Blockchain concept learning games with AI tutors
- Gamified DAO participation with AI rewards
- Smart contract coding challenges with AI feedback

---

## 🎉 Final Words

This course offers a unique opportunity to:
- Work at the cutting edge of technology (AI + Blockchain)
- Build something real and meaningful
- Learn in-demand skills
- Create portfolio projects

**Keys to Success:**
1. Choose a project you're passionate about
2. Start early and iterate
3. Use resources and ask questions
4. Document everything
5. Learn from challenges
6. Deliver something you're proud of

**Good luck with your project!** 🚀

Remember: The goal isn't perfection—it's learning, building, and demonstrating your understanding of AI4Blockchain concepts. Focus on solid fundamentals and a working demonstration rather than trying to build everything perfectly.

---

**Document Version:** 1.0  
**Last Updated:** December 08, 2025  
**Course:** SEN0401 - Special Topics in Software Engineering (Blockchain)  
**Instructor:** Yusuf Altunel  
**Institution:** Istanbul Kültür University, Computer Engineering Department
